import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
  enableProdMode();
}

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));


var arr = [10, 20, 30];

// Impure 
// Modifying any external variable or object property
// Modifying input parameters
// Logging Data to the console
// Writing Data to a file
// Writing Data to the network
// Trigerring any external process
// Calling any other function with impurity
// Making Async Data Calls

// Impure Fn
// function append(dataArray: any[], data: any) {
//   dataArray[dataArray.length] = data;
//   return dataArray;
// }

// Pure Fn
// function append(dataArray: any[], data: any) {
//   var rArr = [...dataArray];
//   rArr[rArr.length] = data;
//   return rArr;
// }

// var newArr1 = append(arr, 100);
// console.log(JSON.stringify(newArr1));         // [10, 20, 30, 100]

// var newArr2 = append(arr, 100);
// console.log(JSON.stringify(newArr2));         // [10, 20, 30, 100]