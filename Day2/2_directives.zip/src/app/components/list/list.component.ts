import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styles: [
  ]
})
export class ListComponent implements OnInit {
  personList: Array<string>;
  selected: string;

  constructor() {
    this.personList = ["Manish", "Abhijeet", "Abhishek", "Ramakant", "Subodh"];
    this.selected = "";
  }

  ngOnInit(): void {
  }

  select(n: string, e: Event) {
    this.selected = n;
    e.preventDefault();
  }
}
