import { Directive, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[isAuthorized]'
})
export class IsAuthorizedDirective implements OnInit {
  constructor(private templateRef: TemplateRef<any>, private viewContRef: ViewContainerRef) { }

  ngOnInit(): void {
    // Get the value of the flag from Authorization Service
    const flag = true;

    if (flag) {
      this.viewContRef.createEmbeddedView(this.templateRef);
    } else {
      this.viewContRef.clear();
    }
  }
}
