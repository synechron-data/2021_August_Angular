// // ----------------------------------------- Default/Automatic Bootstrapping
// import { NgModule } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { HelloComponent } from './components/hello/hello.component';

// @NgModule({
//   imports: [BrowserModule],
//   declarations: [HelloComponent],
//   bootstrap: [HelloComponent]
// })
// export class AppModule { }

// ----------------------------------------- Manual/Custom Bootstrapping
import { ApplicationRef, DoBootstrap, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HelloComponent } from './components/hello/hello.component';
import { HiComponent } from './components/hi/hi.component';

@NgModule({
  imports: [BrowserModule],
  declarations: [HelloComponent, HiComponent]
})
export class AppModule implements DoBootstrap {
  ngDoBootstrap(appRef: ApplicationRef): void {
    const app = document.querySelector("#app");
    let condition = "true";
    
    if (condition) {
      const helloTag = document.createElement('app-hello');
      app?.appendChild(helloTag);
      appRef.bootstrap(HelloComponent);
    } else {
      const hiTag = document.createElement('app-hi');
      app?.appendChild(hiTag);
      appRef.bootstrap(HiComponent);
    }
  }
}
