// npm i bootstrap@4 bootstrap-icons popper.js jquery
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HelloComponent } from './components/hello/hello.component';

@NgModule({
  imports: [BrowserModule],
  declarations: [HelloComponent],
  bootstrap: [HelloComponent]
})
export class AppModule { }