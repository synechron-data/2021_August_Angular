import { Component, Inject, OnInit } from '@angular/core';
import { Author } from 'src/app/models/author.interface';
import { AuthorService } from 'src/app/services/author.service';

@Component({
    selector: 'app-root',
    templateUrl: 'root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [AuthorService]
})

export class RootComponent implements OnInit {
    list?: Array<Author>;
    selectedAuthor?: Author;

    // constructor(@Inject(AuthorService) private authorService: any) { }
    constructor(private authorService: AuthorService) { }

    ngOnInit() {
        this.list = this.authorService.Authors;
    }

    selectAuthor(a: Author) {
        this.selectedAuthor = a;
    }

    isSelected(a: Author) {
        return this.selectedAuthor === a;
    }
}